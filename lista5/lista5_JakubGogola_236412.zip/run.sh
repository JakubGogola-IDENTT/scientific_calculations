#!/bin/bash

julia tests.jl
