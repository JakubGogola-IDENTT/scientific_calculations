# Jakub Gogola 236412
# Module "ZeroMethods" with algorithms form excercises 1-3

module ZeroMethods
    include("./zad1/zad1.jl")
    include("./zad2/zad2.jl")
    include("./zad3/zad3.jl")

    export mbisekcji, mstycznych, msiecznych
end